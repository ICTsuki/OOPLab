package hust.soict.ict.aims.test.disc;

import hust.soict.ict.aims.media.DigitalVideoDisc;

public class TestPassingParameter {
    public static void main(String[] args) {


    }
}
